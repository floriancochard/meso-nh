/* $Header: /tmp/hpctools/ga/tcgmsg/ipcv4.0/signals.h,v 1.5 2004-04-01 02:04:57 manoj Exp $ */

extern void ZapChildren();
extern void TrapSigint();
extern void TrapSigchld();
extern void TrapSigterm();
