var searchData=
[
  ['alloc',['alloc',['../classmod__oasis__namcouple.html#a0d85a5dcb3fab17a680cceed332b9668',1,'mod_oasis_namcouple']]],
  ['augment_5farrays',['augment_arrays',['../classmod__oasis__map.html#a84a573c180be2a5dc8a14fd18b2dc4b7',1,'mod_oasis_map']]]
];
