var searchData=
[
  ['timer_5fdetails',['timer_details',['../structmod__oasis__timer_1_1timer__details.html',1,'mod_oasis_timer']]]
];
