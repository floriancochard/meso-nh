var searchData=
[
  ['new_5flgi_5fmethod2a',['NEW_LGI_METHOD2a',['../mod__oasis__string_8_f90.html#a732dc6b61280242f5cf9c6b817dfd452',1,'mod_oasis_string.F90']]]
];
