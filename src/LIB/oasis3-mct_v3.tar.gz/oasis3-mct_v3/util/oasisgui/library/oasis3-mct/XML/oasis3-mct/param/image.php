<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="x-dns-prefetch-control" content="off">
<script type="text/javascript" language="JavaScript">
<!--
if (self != top) { try { if (document.domain != top.document.domain) { throw "Clickjacking security violation! Please log out immediately!"; /* this code should never execute - exception should already have been thrown since it's a security violation in this case to even try to access top.document.domain (but it's left here just to be extra safe) */ } } catch (e) { self.location = "/src/signout.php"; top.location = "/src/signout.php" } }
// -->
</script>

<title>SquirrelMail</title><script language="JavaScript" type="text/javascript">
<!--
function checkForm() {
   var f = document.forms.length;
   var i = 0;
   var pos = -1;
   while( pos == -1 && i < f ) {
       var e = document.forms[i].elements.length;
       var j = 0;
       while( pos == -1 && j < e ) {
           if ( document.forms[i].elements[j].type == 'text'            || document.forms[i].elements[j].type == 'password' ) {
               pos = j;
           }
           j++;
       }
   i++;
   }
   if( pos >= 0 ) {
       document.forms[i-1].elements[pos].focus();
   }
   
}
// -->
</script>

<!--[if IE 6]>
<style type="text/css">
/* avoid stupid IE6 bug with frames and scrollbars */
body {
    width: expression(document.documentElement.clientWidth - 30);
}
</style>
<![endif]-->

</head>

<body text="#000000" bgcolor="#ffffff" link="#0000cc" vlink="#0000cc" alink="#0000cc" onload="checkForm();">

<a name="pagetop"></a>
<table bgcolor="#ffffff" border="0" width="100%" cellspacing="0" cellpadding="2">

<tr bgcolor="#ababab">

<td align="left">

&nbsp;      </td>
<td align="right">
<b>
<a href="/src/signout.php" target="_top">Sign Out</a></b></td>
   </tr>
<tr bgcolor="#ffffff">

<td align="left">

<a href="/src/compose.php?mailbox=None&amp;startMessage=0">Compose</a>&nbsp;&nbsp;
<a href="/src/addressbook.php">Addresses</a>&nbsp;&nbsp;
<a href="/src/folders.php">Folders</a>&nbsp;&nbsp;
<a href="/src/options.php">Options</a>&nbsp;&nbsp;
<a href="/src/search.php?mailbox=None">Search</a>&nbsp;&nbsp;
<a href="/src/help.php">Help</a>&nbsp;&nbsp;
      </td>
<td align="right">

<a href=" https://dino.cerfacs.fr/" target="_blank">CERFACS</a></td>
   </tr>
</table><br>

<br /><table width="100%" border="0" cellspacing="0" cellpadding="2" align="center">
<tr><td bgcolor="#dcdcdc"><b><center>Viewing an image attachment - <a href="read_body.php?mailbox=INBOX&amp;passed_id=53227&amp;startMessage=1&amp;ent_id=0">View message</a></b></td></tr>
<tr><td align="center">
<a href="../src/download.php?passed_id=53227&amp;mailbox=INBOX&amp;ent_id=2&amp;absolute_dl=true">Download this as a file</a>
<br />&nbsp;</td></tr></table>

<table border="0" cellspacing="0" cellpadding="2" align="center">
<tr><td bgcolor="#ffffff">
<img src="../src/download.php?passed_id=53227&amp;mailbox=INBOX&amp;ent_id=2&amp;absolute_dl=true" />

</td></tr></table>
</body></html>