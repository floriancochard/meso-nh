from XDR import *

init()

print "hello world!"


plugin = loadCodePlugin()



finish()